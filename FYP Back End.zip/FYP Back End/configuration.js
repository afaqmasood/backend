module.exports = {
    mongoDBUrl : "mongodb+srv://Talha:talhafiaz13131313@cluster0.3yjrh.mongodb.net/<dbname>?retryWrites=true&w=majority",
    JWTKey : "J_W_T_U_S_E_R_K_E_Y_T_O_K_E_N@Talha"
};